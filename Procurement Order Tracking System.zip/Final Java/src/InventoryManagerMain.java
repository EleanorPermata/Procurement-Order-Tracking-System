import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class InventoryManagerMain extends JPanel {
    private List<Item> items = new ArrayList<>();
    private List<Supplier> suppliers = new ArrayList<>();
    private JScrollPane inventoryScrollPane, supplierScrollPane;

    public InventoryManagerMain() {
        initComponents();
        loadDataFromFile();
        loadSuppliersFromFile();
    }

    private void initComponents() {
        setLayout(new BorderLayout());
        setBackground(new Color(245, 245, 245));

        // Tabbed Pane
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Segoe UI", Font.BOLD, 14));
        tabbedPane.setBackground(new Color(34, 45, 50));
        tabbedPane.setForeground(Color.WHITE);

        // Inventory Panel
        JPanel inventoryPanel = createStyledPanel("Manage Inventory");
        inventoryScrollPane = new JScrollPane();
        inventoryScrollPane.setPreferredSize(new Dimension(800, 300));
        inventoryPanel.add(inventoryScrollPane, BorderLayout.CENTER);

        JButton addItemButton = createStyledButton("Add New Item", new Color(0, 123, 255));
        addItemButton.addActionListener(e -> showAddItemDialog());

        JPanel inventoryBottomPanel = createBottomPanel();
        inventoryBottomPanel.add(addItemButton);
        inventoryPanel.add(inventoryBottomPanel, BorderLayout.SOUTH);
        tabbedPane.addTab("Manage Stock", inventoryPanel);

        // Supplier Panel
        JPanel supplierPanel = createStyledPanel("Manage Suppliers");
        supplierScrollPane = new JScrollPane();
        supplierScrollPane.setPreferredSize(new Dimension(800, 300));
        supplierPanel.add(supplierScrollPane, BorderLayout.CENTER);

        JButton addSupplierButton = createStyledButton("Add New Supplier", new Color(40, 167, 69));
        addSupplierButton.addActionListener(e -> showAddSupplierDialog());

        JPanel supplierBottomPanel = createBottomPanel();
        supplierBottomPanel.add(addSupplierButton);
        supplierPanel.add(supplierBottomPanel, BorderLayout.SOUTH);
        tabbedPane.addTab("Manage Suppliers", supplierPanel);

        add(tabbedPane, BorderLayout.CENTER);
    }

    private JPanel createStyledPanel(String title) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(240, 240, 240));
        panel.setBorder(new CompoundBorder(new EmptyBorder(10, 10, 10, 10), new LineBorder(Color.LIGHT_GRAY, 1)));

        JLabel titleLabel = new JLabel(title, SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLabel.setForeground(new Color(34, 45, 50));
        panel.add(titleLabel, BorderLayout.NORTH);
        return panel;
    }

    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(new LineBorder(color.darker(), 2, true));
        button.setPreferredSize(new Dimension(180, 40));
        return button;
    }

    private JPanel createBottomPanel() {
        JPanel panel = new JPanel();
        panel.setBackground(new Color(34, 45, 50));
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));
        return panel;
    }

    private void loadDataFromFile() {
        items.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader("itemsSales.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] fields = line.split(",");
                if (fields.length == 5) {
                    items.add(new Item(fields[0], fields[1], fields[2], Integer.parseInt(fields[3]), Integer.parseInt(fields[4])));
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading items file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        displayItemsInScrollPane();
    }

    private void loadSuppliersFromFile() {
        suppliers.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader("suppliers.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] fields = line.split(",");
                if (fields.length == 5) {
                    suppliers.add(new Supplier(fields[0], fields[1], fields[2], fields[3], fields[4]));
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading suppliers file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        displaySuppliersInScrollPane();
    }

    private void saveAllItemsToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("itemsSales.txt"))) {
            for (Item item : items) {
                writer.write(String.format("%s,%s,%s,%d,%d", item.itemName, item.sku, item.category, item.quantity, item.reorderLevel));
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving items.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveAllSuppliersToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("suppliers.txt"))) {
            for (Supplier supplier : suppliers) {
                writer.write(String.format("%s,%s,%s,%s,%s", supplier.name, supplier.contactPerson, supplier.phone, supplier.address, supplier.email));
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving suppliers.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void showAddItemDialog() {
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        JTextField nameField = new JTextField();
        JTextField skuField = new JTextField();
        JTextField categoryField = new JTextField();
        JTextField quantityField = new JTextField();
        JTextField reorderLevelField = new JTextField();

        panel.add(new JLabel("Item Name:")); panel.add(nameField);
        panel.add(new JLabel("SKU:")); panel.add(skuField);
        panel.add(new JLabel("Category:")); panel.add(categoryField);
        panel.add(new JLabel("Quantity:")); panel.add(quantityField);
        panel.add(new JLabel("Reorder Level:")); panel.add(reorderLevelField);

        if (JOptionPane.showConfirmDialog(this, panel, "Add New Item", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
            items.add(new Item(nameField.getText(), skuField.getText(), categoryField.getText(),
                    Integer.parseInt(quantityField.getText()), Integer.parseInt(reorderLevelField.getText())));
            saveAllItemsToFile();
            loadDataFromFile();
        }
    }

    private void showAddSupplierDialog() {
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        JTextField nameField = new JTextField();
        JTextField contactField = new JTextField();
        JTextField phoneField = new JTextField();
        JTextField addressField = new JTextField();
        JTextField emailField = new JTextField();

        panel.add(new JLabel("Supplier Name:")); panel.add(nameField);
        panel.add(new JLabel("Contact Person:")); panel.add(contactField);
        panel.add(new JLabel("Phone:")); panel.add(phoneField);
        panel.add(new JLabel("Address:")); panel.add(addressField);
        panel.add(new JLabel("Email:")); panel.add(emailField);

        if (JOptionPane.showConfirmDialog(this, panel, "Add New Supplier", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
            suppliers.add(new Supplier(nameField.getText(), contactField.getText(), phoneField.getText(),
                    addressField.getText(), emailField.getText()));
            saveAllSuppliersToFile();
            loadSuppliersFromFile();
        }
    }

    private void showEditItemDialog(Item item) {
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        JTextField nameField = new JTextField(item.itemName);
        JTextField skuField = new JTextField(item.sku);
        JTextField categoryField = new JTextField(item.category);
        JTextField quantityField = new JTextField(String.valueOf(item.quantity));
        JTextField reorderLevelField = new JTextField(String.valueOf(item.reorderLevel));

        panel.add(new JLabel("Item Name:")); panel.add(nameField);
        panel.add(new JLabel("SKU:")); panel.add(skuField);
        panel.add(new JLabel("Category:")); panel.add(categoryField);
        panel.add(new JLabel("Quantity:")); panel.add(quantityField);
        panel.add(new JLabel("Reorder Level:")); panel.add(reorderLevelField);

        if (JOptionPane.showConfirmDialog(this, panel, "Edit Item", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
            item.itemName = nameField.getText();
            item.sku = skuField.getText();
            item.category = categoryField.getText();
            item.quantity = Integer.parseInt(quantityField.getText());
            item.reorderLevel = Integer.parseInt(reorderLevelField.getText());
            saveAllItemsToFile();
            loadDataFromFile();
        }
    }

    private void showEditSupplierDialog(Supplier supplier) {
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        JTextField nameField = new JTextField(supplier.name);
        JTextField contactField = new JTextField(supplier.contactPerson);
        JTextField phoneField = new JTextField(supplier.phone);
        JTextField addressField = new JTextField(supplier.address);
        JTextField emailField = new JTextField(supplier.email);

        panel.add(new JLabel("Supplier Name:")); panel.add(nameField);
        panel.add(new JLabel("Contact Person:")); panel.add(contactField);
        panel.add(new JLabel("Phone:")); panel.add(phoneField);
        panel.add(new JLabel("Address:")); panel.add(addressField);
        panel.add(new JLabel("Email:")); panel.add(emailField);

        if (JOptionPane.showConfirmDialog(this, panel, "Edit Supplier", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
            supplier.name = nameField.getText();
            supplier.contactPerson = contactField.getText();
            supplier.phone = phoneField.getText();
            supplier.address = addressField.getText();
            supplier.email = emailField.getText();
            saveAllSuppliersToFile();
            loadSuppliersFromFile();
        }
    }

    private void displayItemsInScrollPane() {
        JPanel containerPanel = createTablePanel(
                new String[]{"Item Name", "SKU", "Category", "Quantity", "Reorder Level", "Edit", "Remove"},
                items.size(),
                (row, column) -> {
                    Item item = items.get(row);
                    switch (column) {
                        case 0: return item.itemName;
                        case 1: return item.sku;
                        case 2: return item.category;
                        case 3: return String.valueOf(item.quantity);
                        case 4: return String.valueOf(item.reorderLevel);
                        case 5: {
                            JButton editButton = createStyledButton("Edit", new Color(255, 193, 7));
                            editButton.addActionListener(e -> showEditItemDialog(item));
                            return editButton;
                        }
                        case 6: {
                            JButton removeButton = createStyledButton("Remove", new Color(220, 53, 69));
                            removeButton.addActionListener(e -> {
                                items.remove(item);
                                saveAllItemsToFile();
                                loadDataFromFile();
                            });
                            return removeButton;
                        }
                    }
                    return "";
                }
        );
        inventoryScrollPane.setViewportView(containerPanel);
    }

    private void displaySuppliersInScrollPane() {
        JPanel containerPanel = createTablePanel(
                new String[]{"Name", "Contact Person", "Phone", "Address", "Email", "Edit", "Remove"},
                suppliers.size(),
                (row, column) -> {
                    Supplier supplier = suppliers.get(row);
                    switch (column) {
                        case 0: return supplier.name;
                        case 1: return supplier.contactPerson;
                        case 2: return supplier.phone;
                        case 3: return supplier.address;
                        case 4: return supplier.email;
                        case 5: {
                            JButton editButton = createStyledButton("Edit", new Color(255, 193, 7));
                            editButton.addActionListener(e -> showEditSupplierDialog(supplier));
                            return editButton;
                        }
                        case 6: {
                            JButton removeButton = createStyledButton("Remove", new Color(220, 53, 69));
                            removeButton.addActionListener(e -> {
                                suppliers.remove(supplier);
                                saveAllSuppliersToFile();
                                loadSuppliersFromFile();
                            });
                            return removeButton;
                        }
                    }
                    return "";
                }
        );
        supplierScrollPane.setViewportView(containerPanel);
    }

    private JPanel createTablePanel(String[] headers, int rows, TableDataProvider dataProvider) {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(new CompoundBorder(
                new LineBorder(new Color(220, 220, 220), 1, true),
                new EmptyBorder(10, 10, 10, 10)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Header Row
        for (int i = 0; i < headers.length; i++) {
            gbc.gridx = i;
            gbc.gridy = 0;
            JLabel headerLabel = new JLabel(headers[i], SwingConstants.CENTER);
            headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
            headerLabel.setForeground(new Color(0, 123, 255));
            panel.add(headerLabel, gbc);
        }

        // Data Rows
        for (int i = 0; i < rows; i++) {
            gbc.gridy = i + 1;
            for (int j = 0; j < headers.length; j++) {
                gbc.gridx = j;
                Object value = dataProvider.getValueAt(i, j);
                if (value instanceof Component) {
                    panel.add((Component) value, gbc);
                } else {
                    JLabel dataLabel = new JLabel(value.toString(), SwingConstants.CENTER);
                    dataLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
                    panel.add(dataLabel, gbc);
                }
            }
        }

        return panel;
    }

    interface TableDataProvider {
        Object getValueAt(int row, int column);
    }

    static class Item {
        public String itemName, sku, category;
        public int quantity, reorderLevel;

        public Item(String itemName, String sku, String category, int quantity, int reorderLevel) {
            this.itemName = itemName;
            this.sku = sku;
            this.category = category;
            this.quantity = quantity;
            this.reorderLevel = reorderLevel;
        }
    }

    static class Supplier {
        public String name, contactPerson, phone, address, email;

        public Supplier(String name, String contactPerson, String phone, String address, String email) {
            this.name = name;
            this.contactPerson = contactPerson;
            this.phone = phone;
            this.address = address;
            this.email = email;
        }
    }
}
