import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.util.Scanner;

public class SalesManagerMain extends JPanel {

    public SalesManagerMain() {
        initComponents();
    }

    private void initComponents() {
        this.setLayout(new BorderLayout());
        this.setBackground(new Color(230, 240, 255)); // Light background for the main panel

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Segoe UI", Font.BOLD, 14));
        tabbedPane.setBackground(new Color(50, 75, 150)); // Tab background
        tabbedPane.setForeground(Color.WHITE); // Tab text color

        tabbedPane.addTab("List of Items", createItemListPanel());
        tabbedPane.addTab("Daily Sales Entry", createDailySalesPanel());
        tabbedPane.addTab("Sales Report", createSalesReportPanel());
        tabbedPane.addTab("Requisitions", createRequisitionPanel());
        tabbedPane.addTab("Purchase Orders", createPurchaseOrdersPanel());
        tabbedPane.addTab("Check Low Stock", createLowStockPanel()); // New Low Stock Tab

        this.add(tabbedPane, BorderLayout.CENTER);
    }

    // ------------------- List of Items Panel -------------------
    private JPanel createItemListPanel() {
        JPanel panel = createStyledPanel("List of Items");

        String[] columnNames = {"Item Name", "SKU", "Category", "Quantity", "Reorder Level"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        JTable table = createStyledTable(tableModel);
        loadItemsFromFile(tableModel);

        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        return panel;
    }

    // ------------------- Daily Sales Entry Panel -------------------
    private JPanel createDailySalesPanel() {
        JPanel panel = createStyledPanel("Daily Sales Entry");

        JPanel formPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(new EmptyBorder(20, 20, 20, 20));

        formPanel.add(new JLabel("Item Name:"));
        JTextField itemNameField = new JTextField();
        formPanel.add(itemNameField);

        formPanel.add(new JLabel("Quantity Sold:"));
        JTextField quantityField = new JTextField();
        formPanel.add(quantityField);

        formPanel.add(new JLabel("Sale Price:"));
        JTextField salePriceField = new JTextField();
        formPanel.add(salePriceField);

        JButton addEntryButton = createStyledButton("Add Entry", new Color(0, 123, 255));
        formPanel.add(addEntryButton);

        String[] columnNames = {"Item Name", "Quantity Sold", "Sale Price", "Total Sale"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        JTable table = createStyledTable(tableModel);

        addEntryButton.addActionListener(e -> {
            String itemName = itemNameField.getText();
            String quantity = quantityField.getText();
            String salePrice = salePriceField.getText();
            if (!itemName.isEmpty() && !quantity.isEmpty() && !salePrice.isEmpty()) {
                int totalSale = Integer.parseInt(quantity) * Integer.parseInt(salePrice);
                tableModel.addRow(new String[]{itemName, quantity, salePrice, String.valueOf(totalSale)});
                saveSaleToFile(itemName, quantity, salePrice, totalSale);
                itemNameField.setText("");
                quantityField.setText("");
                salePriceField.setText("");
            }
        });

        panel.add(formPanel, BorderLayout.NORTH);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        return panel;
    }

    // ------------------- Sales Report Panel -------------------
    private JPanel createSalesReportPanel() {
        JPanel panel = createStyledPanel("Sales Report");

        String[] columnNames = {"Item Name", "Quantity Sold", "Sale Price", "Total Sale"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        JTable table = createStyledTable(tableModel);

        loadSalesFromFile(tableModel);

        JButton updateButton = createStyledButton("Update Report", new Color(255, 159, 28));
        updateButton.addActionListener(e -> {
            tableModel.setRowCount(0); // Clear the table
            loadSalesFromFile(tableModel); // Reload the file data
        });

        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        panel.add(updateButton, BorderLayout.SOUTH);
        return panel;
    }

    // ------------------- Requisition Panel -------------------
private JPanel createRequisitionPanel() {
    JPanel panel = createStyledPanel("Requisitions");

    String[] columnNames = {"Item Name", "SKU", "Category", "Quantity", "Reorder Level"};
    DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
    JTable table = createStyledTable(tableModel);
    loadItemsFromLowStockFile(tableModel);  // Initial load from items.txt

    JButton createRequisitionButton = createStyledButton("Create Requisition", new Color(76, 175, 80));
    createRequisitionButton.addActionListener(e -> {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(panel, "Please select an item to requisition.", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            String itemName = table.getValueAt(selectedRow, 0).toString();
            String sku = table.getValueAt(selectedRow, 1).toString();
            String category = table.getValueAt(selectedRow, 2).toString();
            String quantity = table.getValueAt(selectedRow, 3).toString();
            String reorderLevel = table.getValueAt(selectedRow, 4).toString();

            String message = String.format("Requisition Created:\n\nItem: %s\nSKU: %s\nCategory: %s\nQuantity: %s\nReorder Level: %s", 
                                             itemName, sku, category, quantity, reorderLevel);
            JOptionPane.showMessageDialog(panel, message, "Create Requisition", JOptionPane.INFORMATION_MESSAGE);

            // Save requisition to file
            saveRequisitionToFile(itemName, sku, category, quantity, reorderLevel);

            // Remove the item from the table and update items.txt
            removeItemFromFile(itemName);
            tableModel.removeRow(selectedRow);  // Update table by removing the row
        }
    });

    // Update button to reload the list of items from items.txt
    JButton updateButton = createStyledButton("Update List", new Color(0, 123, 255));
    updateButton.addActionListener(e -> {
        tableModel.setRowCount(0);  // Clear current rows
        loadItemsFromLowStockFile(tableModel);  // Reload items from the updated items.txt
    });

    // Adding the buttons to the panel
    JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
    buttonPanel.add(createRequisitionButton);
    buttonPanel.add(updateButton);

    panel.add(new JScrollPane(table), BorderLayout.CENTER);
    panel.add(buttonPanel, BorderLayout.SOUTH);
    return panel;
}



    // ------------------- Purchase Orders Panel -------------------
    private JPanel createPurchaseOrdersPanel() {
        JPanel panel = createStyledPanel("Purchase Orders");

        String[] columnNames = {"Order ID", "Item Name", "Quantity", "Order Date", "Supplier"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        JTable table = createStyledTable(tableModel);
        loadPurchaseOrdersFromFile(tableModel);

        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        return panel;
    }

    // ------------------- Check Low Stock Panel -------------------
    private JPanel createLowStockPanel() {
    JPanel panel = createStyledPanel("Check Low Stock");

    String[] columnNames = {"Item Name", "SKU", "Category", "Quantity", "Reorder Level"};
    DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
    JTable table = createStyledTable(tableModel);

    JButton checkButton = createStyledButton("Check Low Stock", new Color(255, 87, 34));
    JButton saveToFileButton = createStyledButton("Save", new Color(76, 175, 80));

    // Check Low Stock logic
    checkButton.addActionListener(e -> {
        tableModel.setRowCount(0); // Clear previous results
        checkItemsBelowReorder(tableModel);
    });

    // Save table data to items.txt
    saveToFileButton.addActionListener(e -> {
        saveLowStockToFile(tableModel);
        JOptionPane.showMessageDialog(panel, "Low stock items saved to items.txt.", "Success", JOptionPane.INFORMATION_MESSAGE);
    });

    JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
    buttonPanel.add(checkButton);
    buttonPanel.add(saveToFileButton);

    panel.add(new JScrollPane(table), BorderLayout.CENTER);
    panel.add(buttonPanel, BorderLayout.SOUTH);
    return panel;
}


    // ------------------- Utility Methods -------------------
    private void removeItemFromFile(String itemName) {
    try {
        File inputFile = new File("items.txt");
        File tempFile = new File("items_temp.txt");

        BufferedReader reader = new BufferedReader(new FileReader(inputFile));
        BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));

        String currentLine;

        while ((currentLine = reader.readLine()) != null) {
            // Split the current line to get the item name
            String[] itemData = currentLine.split(",");
            if (itemData.length > 0 && !itemData[0].equals(itemName)) {
                // Write lines that don't match the itemName to the temp file
                writer.write(currentLine + System.lineSeparator());
            }
        }
        reader.close();
        writer.close();

        // Delete the original file and rename the temp file
        if (inputFile.delete()) {
            if (tempFile.renameTo(inputFile)) {
                System.out.println("Item removed successfully.");
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
}

    
    private void saveLowStockToFile(DefaultTableModel tableModel) {
    try (FileWriter writer = new FileWriter("items.txt")) {
        int rowCount = tableModel.getRowCount();
        int columnCount = tableModel.getColumnCount();

        for (int i = 0; i < rowCount; i++) {
            StringBuilder row = new StringBuilder();
            for (int j = 0; j < columnCount; j++) {
                row.append(tableModel.getValueAt(i, j).toString());
                if (j < columnCount - 1) {
                    row.append(",");
                }
            }
            writer.write(row.toString() + "\n");
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
}

    private void checkItemsBelowReorder(DefaultTableModel tableModel) {
        try (Scanner scanner = new Scanner(new File("itemsSales.txt"))) {
            while (scanner.hasNextLine()) {
                String[] itemData = scanner.nextLine().split(",");
                if (itemData.length >= 5) {
                    String itemName = itemData[0];
                    String sku = itemData[1];
                    String category = itemData[2];
                    int quantity = Integer.parseInt(itemData[3]);
                    int reorderLevel = Integer.parseInt(itemData[4]);
                    if (quantity < reorderLevel) {
                        tableModel.addRow(new String[]{itemName, sku, category, String.valueOf(quantity), String.valueOf(reorderLevel)});
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void saveLowStockItemsToFile(DefaultTableModel tableModel) {
        try (FileWriter writer = new FileWriter("items.txt")) {
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                StringBuilder row = new StringBuilder();
                for (int j = 0; j < tableModel.getColumnCount(); j++) {
                    row.append(tableModel.getValueAt(i, j));
                    if (j < tableModel.getColumnCount() - 1) {
                        row.append(",");
                    }
                }
                writer.write(row.toString() + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadItemsFromLowStockFile(DefaultTableModel tableModel) {
        try (Scanner scanner = new Scanner(new File("items.txt"))) {
            while (scanner.hasNextLine()) {
                tableModel.addRow(scanner.nextLine().split(","));
            }
        } catch (IOException e) {
            System.out.println("items.txt not found.");
        }
    }

    private JPanel createStyledPanel(String title) {
        JPanel panel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gradient = new GradientPaint(0, 0, new Color(80, 150, 200), getWidth(), getHeight(), new Color(200, 230, 255));
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JLabel titleLabel = new JLabel(title, SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        panel.add(titleLabel, BorderLayout.NORTH);

        return panel;
    }

    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 16));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(color.darker(), 2, true));

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(color.darker());
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(color);
            }
        });

        return button;
    }

    private JTable createStyledTable(DefaultTableModel tableModel) {
        JTable table = new JTable(tableModel);
        table.setFont(new Font("Arial", Font.PLAIN, 14));
        table.setRowHeight(30);
        return table;
    }

    private void loadItemsFromFile(DefaultTableModel tableModel) {
        try (Scanner scanner = new Scanner(new File("itemsSales.txt"))) {
            while (scanner.hasNextLine()) {
                tableModel.addRow(scanner.nextLine().split(","));
            }
        } catch (IOException e) {
            System.out.println("itemsSales.txt not found.");
        }
    }

    private void loadSalesFromFile(DefaultTableModel tableModel) {
        try (Scanner scanner = new Scanner(new File("sales.txt"))) {
            while (scanner.hasNextLine()) {
                tableModel.addRow(scanner.nextLine().split(","));
            }
        } catch (IOException e) {
            System.out.println("sales.txt not found.");
        }
    }

    private void loadPurchaseOrdersFromFile(DefaultTableModel tableModel) {
        try (Scanner scanner = new Scanner(new File("purchase_orders.txt"))) {
            while (scanner.hasNextLine()) {
                tableModel.addRow(scanner.nextLine().split(","));
            }
        } catch (IOException e) {
            System.out.println("purchase_orders.txt not found.");
        }
    }

    private void saveRequisitionToFile(String itemName, String sku, String category, String quantity, String reorderLevel) {
        try (FileWriter writer = new FileWriter("requisitions.txt", true)) {
            writer.write(String.join(",", itemName, sku, category, quantity, reorderLevel) + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void saveSaleToFile(String itemName, String quantity, String salePrice, int totalSale) {
        try (FileWriter writer = new FileWriter("sales.txt", true)) {
            writer.write(String.join(",", itemName, quantity, salePrice, String.valueOf(totalSale)) + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

