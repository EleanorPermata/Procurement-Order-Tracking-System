import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.time.LocalDate;
import java.util.Vector;

public class FinanceManagerMain extends JPanel {

    public FinanceManagerMain() {
        initComponents();
    }

    private void initComponents() {
        this.setLayout(new BorderLayout());

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Segoe UI", Font.BOLD, 14));
        tabbedPane.setBackground(new Color(34, 45, 50));
        tabbedPane.setForeground(Color.WHITE);

        tabbedPane.addTab("Verify POs for Payment", createVerifyPOPanel());
        tabbedPane.addTab("Make Payment", createMakePaymentPanel());
        tabbedPane.addTab("View Supplier Payment Status", createSupplierPaymentStatusPanel());

        this.add(tabbedPane, BorderLayout.CENTER);
    }

    // ------------------- Verify POs for Payment -------------------
    private JPanel createVerifyPOPanel() {
        JPanel panel = createStyledPanel("Verify POs for Payment");

        String[] columnNames = {"PO ID", "Supplier", "Item Name", "Quantity", "Status"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        JTable table = createStyledTable(tableModel);
        loadTableData("purchase_orders.txt", tableModel);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(245, 245, 245));
        JButton approveButton = createStyledButton("Approve", new Color(76, 175, 80));
        JButton rejectButton = createStyledButton("Reject", new Color(220, 53, 69));

        approveButton.addActionListener(e -> updatePOStatus(table, tableModel, "Approved"));
        rejectButton.addActionListener(e -> updatePOStatus(table, tableModel, "Rejected"));

        buttonPanel.add(approveButton);
        buttonPanel.add(rejectButton);

        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        return panel;
    }

    private void updatePOStatus(JTable table, DefaultTableModel tableModel, String status) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            tableModel.setValueAt(status, selectedRow, 4);
            saveUpdatedTableToFile("purchase_orders.txt", tableModel);
            JOptionPane.showMessageDialog(this, "PO status updated to " + status);
        } else {
            JOptionPane.showMessageDialog(this, "Please select a PO to update.");
        }
    }

    // ------------------- Make Payment -------------------
    private JPanel createMakePaymentPanel() {
        JPanel panel = createStyledPanel("Make Payment");

        String[] columnNames = {"PO ID", "Supplier", "Item Name", "Quantity", "Status"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        JTable table = createStyledTable(tableModel);
        loadTableData("purchase_orders.txt", tableModel);

        JPanel mainContainer = new JPanel(new BorderLayout(10, 10));
        mainContainer.setBackground(new Color(245, 245, 245));

        // Form for payment details
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(new Color(245, 245, 245));
        formPanel.setBorder(BorderFactory.createTitledBorder("Payment Details"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel poIdLabel = new JLabel("PO ID:");
        JTextField poIdField = new JTextField(15);
        JLabel amountLabel = new JLabel("Amount:");
        JTextField amountField = new JTextField(15);

        JButton makePaymentButton = createStyledButton("Make Payment", new Color(0, 123, 255));

        makePaymentButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                String poId = tableModel.getValueAt(selectedRow, 0).toString();
                String supplier = tableModel.getValueAt(selectedRow, 1).toString();
                String amount = amountField.getText();
                if (!amount.trim().isEmpty()) {
                    tableModel.setValueAt("Paid", selectedRow, 4);
                    saveUpdatedTableToFile("purchase_orders.txt", tableModel);
                    saveSupplierPayment(supplier, amount);
                    JOptionPane.showMessageDialog(this, "Payment processed for PO ID: " + poId);
                    poIdField.setText("");
                    amountField.setText("");
                } else {
                    JOptionPane.showMessageDialog(this, "Please enter the payment amount.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please select a PO to make payment.");
            }
        });

        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(poIdLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(poIdField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(amountLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(amountField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        formPanel.add(makePaymentButton, gbc);

        mainContainer.add(new JScrollPane(table), BorderLayout.CENTER);
        mainContainer.add(formPanel, BorderLayout.SOUTH);
        panel.add(mainContainer, BorderLayout.CENTER);

        return panel;
    }

    private void saveSupplierPayment(String supplier, String amount) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("supplier_payments.txt", true))) {
            writer.write(supplier + "," + amount + ",Paid," + LocalDate.now());
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // ------------------- View Supplier Payment Status -------------------
    // ------------------- View Supplier Payment Status -------------------
private JPanel createSupplierPaymentStatusPanel() {
    JPanel panel = createStyledPanel("Supplier Payment Status");

    String[] columnNames = {"Supplier Name", "Payment Amount", "Status", "Date"};
    DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
    JTable table = createStyledTable(tableModel);
    loadTableData("supplier_payments.txt", tableModel);

    // Create the "Update List" button
    JButton updateButton = createStyledButton("Update List", new Color(0, 123, 255));

    // Add the button's action listener to reload data
    updateButton.addActionListener(e -> {
        tableModel.setRowCount(0); // Clear the table
        loadTableData("supplier_payments.txt", tableModel); // Reload the file data
    });

    // Add components to the panel
    panel.add(new JScrollPane(table), BorderLayout.CENTER);
    panel.add(updateButton, BorderLayout.SOUTH); // Add the button at the bottom of the panel

    return panel;
}


    // ------------------- Utility Methods -------------------
    private void loadTableData(String fileName, DefaultTableModel tableModel) {
        tableModel.setRowCount(0);
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                tableModel.addRow(line.split(","));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void saveUpdatedTableToFile(String fileName, DefaultTableModel tableModel) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                Vector<?> row = tableModel.getDataVector().elementAt(i);
                writer.write(String.join(",", row.toArray(new String[0])));
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private JPanel createStyledPanel(String title) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 245, 245));
        panel.setBorder(new CompoundBorder(new EmptyBorder(10, 10, 10, 10), new LineBorder(Color.LIGHT_GRAY, 1)));

        JLabel titleLabel = new JLabel(title, SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLabel.setForeground(new Color(34, 45, 50));
        panel.add(titleLabel, BorderLayout.NORTH);

        return panel;
    }

    private JTable createStyledTable(DefaultTableModel tableModel) {
        JTable table = new JTable(tableModel);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setRowHeight(30);
        table.setGridColor(new Color(200, 200, 200));
        table.setSelectionBackground(new Color(0, 123, 255));
        table.setSelectionForeground(Color.WHITE);
        return table;
    }

    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(new LineBorder(color.darker(), 2, true));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }
}
