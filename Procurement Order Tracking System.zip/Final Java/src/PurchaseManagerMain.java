import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.util.Vector;

public class PurchaseManagerMain extends JPanel {

    public PurchaseManagerMain() {
        initComponents();
    }

    private void initComponents() {
        this.setLayout(new BorderLayout());
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Segoe UI", Font.BOLD, 14));
        tabbedPane.setBackground(new Color(34, 45, 50));
        tabbedPane.setForeground(Color.WHITE);

        tabbedPane.addTab("List of Items", createItemListPanel());
        tabbedPane.addTab("List of Suppliers", createSupplierListPanel());
        tabbedPane.addTab("Generate Purchase Order", createPurchaseOrderPanel());
        tabbedPane.addTab("List of Purchase Orders", createPurchaseOrderListPanel());

        this.add(tabbedPane, BorderLayout.CENTER);
    }

    // ------------------- List of Items -------------------
    private JPanel createItemListPanel() {
        JPanel panel = createStyledPanel("List of Items");

        String[] columnNames = {"Item Name", "SKU", "Category", "Quantity", "Reorder Level"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        JTable table = createStyledTable(tableModel);
        loadTableData("itemsSales.txt", tableModel);

        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        return panel;
    }

    // ------------------- List of Suppliers -------------------
    private JPanel createSupplierListPanel() {
        JPanel panel = createStyledPanel("List of Suppliers");

        String[] columnNames = {"Supplier Name", "Contact", "Email", "Address"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        JTable table = createStyledTable(tableModel);
        loadTableData("suppliers.txt", tableModel);

        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        return panel;
    }

    // ------------------- Generate Purchase Order -------------------
    private JPanel createPurchaseOrderPanel() {
        JPanel panel = createStyledPanel("Generate Purchase Order");

        // Table to display requisitions
        String[] requisitionColumns = {"Requisition ID", "Item Name", "Quantity", "Date"};
        DefaultTableModel requisitionTableModel = new DefaultTableModel(requisitionColumns, 0);
        JTable requisitionTable = createStyledTable(requisitionTableModel);
        loadRequisitions("requisitions.txt", requisitionTableModel);

        // Requisition Table
        JScrollPane requisitionScrollPane = new JScrollPane(requisitionTable);
        requisitionScrollPane.setPreferredSize(new Dimension(700, 200));

        // Form Panel for Purchase Order
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;

        // Order ID Field
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(new JLabel("Order ID:"), gbc);
        gbc.gridx = 1;
        JTextField orderIdField = new JTextField(15);
        formPanel.add(orderIdField, gbc);

        // Supplier Name Field
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(new JLabel("Supplier Name:"), gbc);
        gbc.gridx = 1;
        JTextField supplierField = new JTextField(15);
        formPanel.add(supplierField, gbc);

        // Generate Button at the Bottom
        JButton generateButton = createStyledButton("Generate Purchase Order", new Color(0, 123, 255));
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        formPanel.add(generateButton, gbc);

        // Button Action Logic
        generateButton.addActionListener(e -> {
            int selectedRow = requisitionTable.getSelectedRow();
            if (selectedRow != -1) {
                String orderId = orderIdField.getText();
                String supplierName = supplierField.getText();
                String itemName = requisitionTableModel.getValueAt(selectedRow, 1).toString();
                String quantity = requisitionTableModel.getValueAt(selectedRow, 2).toString();
                String requisitionId = requisitionTableModel.getValueAt(selectedRow, 0).toString();

                if (!orderId.isEmpty() && !supplierName.isEmpty()) {
                    // Save the purchase order
                    savePurchaseOrder(orderId, supplierName, itemName, quantity);

                    // Remove the requisition
                    removeRequisitionFromFile("requisitions.txt", requisitionId);

                    // Refresh the table
                    loadRequisitions("requisitions.txt", requisitionTableModel);

                    JOptionPane.showMessageDialog(panel, "Purchase Order Generated Successfully!");
                    orderIdField.setText("");
                    supplierField.setText("");
                } else {
                    JOptionPane.showMessageDialog(panel, "Order ID and Supplier Name are required!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(panel, "Please select a requisition.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Final Layout
        panel.add(requisitionScrollPane, BorderLayout.NORTH);
        panel.add(formPanel, BorderLayout.CENTER);
        return panel;
    }

    // ------------------- List of Purchase Orders -------------------
    // ------------------- List of Purchase Orders -------------------
    private JPanel createPurchaseOrderListPanel() {
    JPanel panel = createStyledPanel("List of Purchase Orders");

    String[] columnNames = {"Order ID", "Supplier", "Item Name", "Quantity", "Status"};
    DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
    JTable table = createStyledTable(tableModel);

    // Load initial data from the file
    loadTableData("purchase_orders.txt", tableModel);

    // Create the "Update List" button
    JButton updateButton = createStyledButton("Update List", new Color(0, 123, 255));

    // Add the button's action listener to reload data
    updateButton.addActionListener(e -> {
        tableModel.setRowCount(0); // Clear the table
        loadTableData("purchase_orders.txt", tableModel); // Reload the file data
    });

    // Add components to the panel
    panel.add(new JScrollPane(table), BorderLayout.CENTER);
    panel.add(updateButton, BorderLayout.SOUTH); // Add the button at the bottom of the panel

    return panel;
}


    // ------------------- Utility Methods -------------------
    private void loadTableData(String fileName, DefaultTableModel tableModel) {
        tableModel.setRowCount(0);
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                tableModel.addRow(line.split(","));
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading data from " + fileName, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadRequisitions(String fileName, DefaultTableModel tableModel) {
        tableModel.setRowCount(0);
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                tableModel.addRow(line.split(","));
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading requisitions.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void savePurchaseOrder(String orderId, String supplier, String itemName, String quantity) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("purchase_orders.txt", true))) {
            writer.write(String.join(",", orderId, supplier, itemName, quantity, "null"));
            writer.newLine();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving purchase order.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private JPanel createStyledPanel(String title) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 245, 245));
        panel.setBorder(new CompoundBorder(new EmptyBorder(10, 10, 10, 10), new LineBorder(Color.LIGHT_GRAY, 1)));

        JLabel titleLabel = new JLabel(title, SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLabel.setForeground(new Color(34, 45, 50));
        panel.add(titleLabel, BorderLayout.NORTH);

        return panel;
    }

    private JTable createStyledTable(DefaultTableModel tableModel) {
        JTable table = new JTable(tableModel);
        table.setFont(new Font("Arial", Font.PLAIN, 14));
        table.setRowHeight(30);
        return table;
    }

    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(new LineBorder(color.darker(), 2, true));
        return button;
    }

    private void removeRequisitionFromFile(String fileName, String requisitionId) {
    File inputFile = new File(fileName);
    File tempFile = new File("temp_requisitions.txt");

    try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
         BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {

        String line;
        boolean found = false;
        while ((line = reader.readLine()) != null) {
            String[] data = line.split(",");
            if (!data[0].equals(requisitionId)) {
                writer.write(line);  // Write the line to the new file if it's not the one to remove
                writer.newLine();
            } else {
                found = true;  // Found and removed the requisition line
            }
        }

        // Check if the requisition was actually found and removed
        if (!found) {
            JOptionPane.showMessageDialog(this, "Requisition ID not found.", "Error", JOptionPane.ERROR_MESSAGE);
        }

    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error updating requisitions file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

    // Replace the original file with the updated file
    if (tempFile.exists() && inputFile.exists()) {
        if (!inputFile.delete()) {
            JOptionPane.showMessageDialog(this, "Error deleting old requisitions file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        if (!tempFile.renameTo(inputFile)) {
            JOptionPane.showMessageDialog(this, "Error renaming updated file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

}
