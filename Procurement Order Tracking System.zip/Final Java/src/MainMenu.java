import javax.swing.*;
import java.awt.*;

public class MainMenu extends JFrame {

    public MainMenu(java.awt.Frame parent, boolean modal) {
        super();
        initComponents();
    }

    private void initComponents() {
        // Panels and Labels
        jPanel1 = new JPanel();
        jPanel7 = new JPanel();
        jLabel1 = new JLabel();
        label1 = new Label();

        // Buttons
        jButton1 = new JButton();
        jButton2 = new JButton();
        jButton3 = new JButton();
        jButton4 = new JButton();
        jButton5 = new JButton();

        // Main frame settings
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Procurement Order Tracking System");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setResizable(false);

        // Header Panel
        jPanel1.setBackground(new Color(41, 50, 65)); // Dark gray-blue
        jPanel1.setLayout(new FlowLayout(FlowLayout.CENTER));

        jLabel1.setFont(new Font("Arial", Font.BOLD, 24));
        jLabel1.setForeground(Color.WHITE);
        jLabel1.setText("PROCUREMENT ORDER TRACKING SYSTEM (POTS)");
        jPanel1.add(jLabel1);

        // Menu Panel
        jPanel7.setBackground(new Color(240, 240, 240)); // Light gray
        jPanel7.setLayout(new GridBagLayout());
        jPanel7.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // Padding

        label1.setFont(new Font("Tahoma", Font.BOLD, 20));
        label1.setText("Menu");
        label1.setAlignment(Label.CENTER);
        label1.setPreferredSize(new Dimension(100, 40));

        // Buttons Styling
        customizeButton(jButton1, "Administration Login");
        customizeButton(jButton2, "1. Sales Manager (SM)");
        customizeButton(jButton3, "2. Purchase Manager (PM)");
        customizeButton(jButton4, "3. Inventory Manager (IM)");
        customizeButton(jButton5, "4. Finance Manager (FM)");

        // Adding components to the menu panel with GridBagLayout
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Padding around components
        gbc.gridx = 0;
        gbc.gridy = 0;
        jPanel7.add(label1, gbc);

        gbc.gridy++;
        jPanel7.add(jButton1, gbc);

        gbc.gridy++;
        jPanel7.add(jButton2, gbc);

        gbc.gridy++;
        jPanel7.add(jButton3, gbc);

        gbc.gridy++;
        jPanel7.add(jButton4, gbc);

        gbc.gridy++;
        jPanel7.add(jButton5, gbc);

        // Main Layout
        setLayout(new BorderLayout());
        add(jPanel1, BorderLayout.NORTH);
        add(jPanel7, BorderLayout.CENTER);

        pack();
    }

    private void customizeButton(JButton button, String text) {
        button.setText(text);
        button.setFont(new Font("Verdana", Font.BOLD, 16));
        button.setBackground(new Color(41, 128, 185)); // Modern blue
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(new Color(34, 112, 168), 2)); // Slightly darker border
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(300, 50));
        button.addActionListener(evt -> openLoginDialog(text));
    }

    private void openLoginDialog(String role) {
        LoginDialog loginDialog = new LoginDialog(new JFrame(), role); // Pass an instance of JFrame
        loginDialog.setVisible(true);
    }

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {
            System.err.println("Failed to set look and feel: " + ex);
        }

        java.awt.EventQueue.invokeLater(() -> {
            MainMenu dialog = new MainMenu(new JFrame(), true);
            dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                @Override
                public void windowClosing(java.awt.event.WindowEvent e) {
                    System.exit(0);
                }
            });
            dialog.setVisible(true);
        });
    }

    // Variables declaration - do not modify
    private JButton jButton1;
    private JButton jButton2;
    private JButton jButton3;
    private JButton jButton4;
    private JButton jButton5;
    private JLabel jLabel1;
    private JPanel jPanel1;
    private JPanel jPanel7;
    private Label label1;
}
