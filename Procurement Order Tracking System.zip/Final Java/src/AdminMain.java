import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class AdminMain extends JPanel {
    private JTable userTable;
    private DefaultTableModel tableModel;
    private JButton btnAddUser, btnRemoveUser, btnLogInAsUser;
    private List<UserModel> userModels;

    public AdminMain() {
        setLayout(new BorderLayout());
        setBackground(new Color(240, 248, 255)); // Light blue background

        // Title Panel
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(new Color(0, 102, 204)); // Blue color
        titlePanel.setBorder(new EmptyBorder(10, 0, 10, 0));
        JLabel titleLabel = new JLabel("Administrator Dashboard");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel);
        add(titlePanel, BorderLayout.NORTH);

        // Load user data
        userModels = new ArrayList<>();
        loadDataFromFile();

        // Center Panel with User Table
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        centerPanel.setBackground(new Color(240, 248, 255));

        // User Table
        String[] columnNames = {"Name", "Email", "Role"};
        tableModel = new DefaultTableModel(columnNames, 0);
        userTable = new JTable(tableModel);
        userTable.setRowHeight(30);
        userTable.setFont(new Font("SansSerif", Font.PLAIN, 14));
        userTable.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 16));
        userTable.getTableHeader().setBackground(new Color(0, 102, 204));
        userTable.getTableHeader().setForeground(Color.WHITE);
        loadUsersIntoTable();

        JScrollPane tableScrollPane = new JScrollPane(userTable);
        tableScrollPane.setBorder(BorderFactory.createLineBorder(new Color(0, 102, 204), 2));
        centerPanel.add(tableScrollPane, BorderLayout.CENTER);
        add(centerPanel, BorderLayout.CENTER);

        // Bottom Panel for Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(new Color(240, 248, 255));

        btnAddUser = createStyledButton("Add User", new Color(0, 153, 51));
        btnRemoveUser = createStyledButton("Remove User", new Color(204, 0, 0));
        btnLogInAsUser = createStyledButton("Log In as Selected User", new Color(0, 102, 204));

        buttonPanel.add(btnAddUser);
        buttonPanel.add(btnRemoveUser);
        buttonPanel.add(btnLogInAsUser);

        add(buttonPanel, BorderLayout.SOUTH);

        // Button Actions
        btnAddUser.addActionListener(e -> addUser());
        btnRemoveUser.addActionListener(e -> removeUser());
        btnLogInAsUser.addActionListener(e -> logInAsSelectedUser());
    }

    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("SansSerif", Font.BOLD, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        return button;
    }

    private void loadDataFromFile() {
        String filePath = "users.txt";
        userModels.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] fields = line.split(",");
                if (fields.length == 4) {
                    UserModel user = new UserModel();
                    user.setName(fields[0]);
                    user.setEmail(fields[1]);
                    user.setPassword(fields[2]);
                    user.setRole(fields[3]);
                    userModels.add(user);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveDataToFile() {
        String filePath = "users.txt";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (UserModel user : userModels) {
                writer.write(user.getName() + "," + user.getEmail() + "," + user.getPassword() + "," + user.getRole());
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadUsersIntoTable() {
        tableModel.setRowCount(0); // Clear existing rows
        for (UserModel user : userModels) {
            tableModel.addRow(new Object[]{user.getName(), user.getEmail(), user.getRole()});
        }
    }

    private void addUser() {
        JTextField nameField = new JTextField();
        JTextField emailField = new JTextField();
        JTextField passwordField = new JTextField();
        String[] roles = {"Admin", "IM", "PM", "SM", "SP", "FM"};
        JComboBox<String> roleComboBox = new JComboBox<>(roles);

        Object[] message = {
                "Name:", nameField,
                "Email:", emailField,
                "Password:", passwordField,
                "Role:", roleComboBox
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Add User", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String name = nameField.getText();
            String email = emailField.getText();
            String password = passwordField.getText();
            String role = (String) roleComboBox.getSelectedItem();

            if (!name.isEmpty() && !email.isEmpty() && !password.isEmpty() && role != null) {
                UserModel newUser = new UserModel();
                newUser.setName(name);
                newUser.setEmail(email);
                newUser.setPassword(password);
                newUser.setRole(role);
                userModels.add(newUser);
                tableModel.addRow(new Object[]{name, email, role});
                saveDataToFile();
            } else {
                JOptionPane.showMessageDialog(this, "All fields are required.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void removeUser() {
        int selectedRow = userTable.getSelectedRow();
        if (selectedRow >= 0) {
            userModels.remove(selectedRow);
            tableModel.removeRow(selectedRow);
            saveDataToFile();
        } else {
            JOptionPane.showMessageDialog(this, "Please select a user to remove.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void logInAsSelectedUser() {
        int selectedRow = userTable.getSelectedRow();
        if (selectedRow >= 0) {
            UserModel selectedUser = userModels.get(selectedRow);
            switch (selectedUser.getRole()) {
                case "SM":
                    openRoleDashboard(new SalesManagerMain(), "Sales Manager Dashboard");
                    break;
                case "PM":
                    openRoleDashboard(new PurchaseManagerMain(), "Purchase Manager Dashboard");
                    break;
                case "IM":
                    openRoleDashboard(new InventoryManagerMain(), "Inventory Manager Dashboard");
                    break;
                case "FM":
                    openRoleDashboard(new FinanceManagerMain(), "Finance Manager Dashboard");
                    break;
                default:
                    JOptionPane.showMessageDialog(this, "Role not supported for login.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a user to log in as.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void openRoleDashboard(JPanel rolePanel, String title) {
        JFrame roleFrame = new JFrame(title);
        roleFrame.setContentPane(rolePanel);
        roleFrame.setSize(800, 600);
        roleFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        roleFrame.setLocationRelativeTo(null);
        roleFrame.setVisible(true);
    }
}
