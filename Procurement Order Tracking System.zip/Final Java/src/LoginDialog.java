import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class LoginDialog extends JDialog {
    private JLabel titleLabel;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton, cancelButton;
    private JFrame parentFrame; // Reference to the parent frame
    private String role;
    List<UserModel> userModels=new ArrayList<>();
    public LoginDialog(JFrame parent, String role) {
        super(parent, "Login Form", true);
        this.parentFrame = parent; // Save the reference to the parent frame
        this.role = role;
        initComponents(role);
    }

    private void initComponents(String role) {
        this.role=role.trim();
        setTitle("Login - " + this.role);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        setResizable(false);

        JPanel centerPanel = new JPanel();
        JPanel buttonPanel = new JPanel();

        titleLabel = new JLabel("Login as: " + role);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);

        usernameField = new JTextField(20);
        passwordField = new JPasswordField(20);

        loginButton = new JButton("Login");
        cancelButton = new JButton("Cancel");

        loginButton.addActionListener(e -> handleLogin());
        cancelButton.addActionListener(e -> dispose());

        centerPanel.setLayout(new GridLayout(3, 2, 10, 10));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        centerPanel.add(new JLabel("Username:"));
        centerPanel.add(usernameField);
        centerPanel.add(new JLabel("Password:"));
        centerPanel.add(passwordField);

        buttonPanel.setLayout(new FlowLayout());
        buttonPanel.add(loginButton);
        buttonPanel.add(cancelButton);

        add(titleLabel, BorderLayout.NORTH);
        add(centerPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(null); // Center the dialog
    }
    private void loadDataFromFile() {
        String filePath = "users.txt"; // Path to the file

        userModels.clear();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;

            while ((line = reader.readLine()) != null) {
                // Split the line by commas
                String[] fields = line.split(",");
                if (fields.length == 4) {
                    // Create a UserModel object and populate its fields
                    UserModel user = new UserModel();
                    user.setName(fields[0]);
                    user.setEmail(fields[1]);
                    user.setPassword(fields[2]);
                    user.setRole(fields[3]);

                    // Add the UserModel object to the list
                    userModels.add(user);
                } else {
                    System.out.println("Invalid line format: " + line);
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }

    }


    private void handleLogin() {
     loadDataFromFile();

     String username = usernameField.getText();
     String password = new String(passwordField.getPassword());

     if (!username.isEmpty() && !password.isEmpty()) {
         if (role.equals("Admin")) {
             UserModel adminUser = null;
             for (UserModel user : userModels) {
                 if (user.getEmail().equals(username) && user.getPassword().equals(password) && user.getRole().equals("Administrator")) {
                     adminUser = user;
                     break;
                 }
             }
             if (adminUser != null) {
                JOptionPane.showMessageDialog(this, "Login Successful", "Success", JOptionPane.INFORMATION_MESSAGE);
                if (parentFrame != null) {
                    parentFrame.dispose();
                }
    // Open the Administrator Dashboard directly
                AdminMain adminFrame = new AdminMain();
                adminFrame.setVisible(true);
                dispose(); // Close the login dialog
} else {
    JOptionPane.showMessageDialog(this, "Invalid Login Data", "Error", JOptionPane.ERROR_MESSAGE);
}
         } else {
             // The existing logic for other roles (SM, PM, IM, FM)
             UserModel userModel = null;
             for (UserModel us : userModels) {
                 if (us.getEmail().equals(username) && us.getPassword().equals(password)) {
                     userModel = us;
                     break;
                 }
             }
             if (userModel == null) {
                 JOptionPane.showMessageDialog(this, "User with this email and password not found", "Error", JOptionPane.ERROR_MESSAGE);
             } else {
                 // Perform role-based actions
                 if (userModel.getRole().equals("SM")) {
                     JFrame smFrame = new JFrame("Sales Manager Dashboard");
                     smFrame.setContentPane(new SalesManagerMain());
                     smFrame.setSize(800, 600);
                     smFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                     smFrame.setVisible(true);
                 } else if (userModel.getRole().equals("PM")) {
                     JFrame pmFrame = new JFrame("Purchase Manager Dashboard");
                     pmFrame.setContentPane(new PurchaseManagerMain());
                     pmFrame.setSize(800, 600);
                     pmFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                     pmFrame.setVisible(true);
                 } else if (userModel.getRole().equals("IM")) {
                     JFrame imFrame = new JFrame("Inventory Manager Dashboard");
                     imFrame.setContentPane(new InventoryManagerMain());
                     imFrame.setSize(800, 600);
                     imFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                     imFrame.setVisible(true);
                 } else if (userModel.getRole().equals("FM")) {
                     JFrame fmFrame = new JFrame("Finance Manager Dashboard");
                     fmFrame.setContentPane(new FinanceManagerMain());
                     fmFrame.setSize(800, 600);
                     fmFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                     fmFrame.setVisible(true);
                 }   else if (userModel.getRole().equals("Admin")) {
                     JFrame fmFrame = new JFrame("Admin Dashboard");
                     fmFrame.setContentPane(new AdminMain());
                     fmFrame.setSize(800, 600);
                     fmFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                     fmFrame.setVisible(true);
                 }
                 dispose(); // Close the dialog
             }
         }
     } else {
         JOptionPane.showMessageDialog(this, "Please fill in both fields", "Error", JOptionPane.ERROR_MESSAGE);
     }
 }
}
